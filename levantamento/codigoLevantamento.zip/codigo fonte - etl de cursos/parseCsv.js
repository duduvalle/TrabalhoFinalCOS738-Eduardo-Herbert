const fs = require('fs')
const { Parser } = require('json2csv')
const etlFinal = require('./json/etlFinal.json')

const fields = ['grupo', 'text'];
const opts = { fields, delimiter: ';' };

try {
  const parser = new Parser(opts);
  const csv = parser.parse(etlFinal);
  fs.writeFileSync('./csv/etlFinal.csv', csv)
} catch (err) {
  console.error(err);
}