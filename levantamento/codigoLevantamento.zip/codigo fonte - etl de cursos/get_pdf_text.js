const crawler = require('crawler-request');


const get_pdf_text = async (url) => {
    try {
        const response = await crawler(url)
        return response.text
    } catch (error) {
        console.log('deu erro')
    }
}

module.exports = get_pdf_text