const fs = require('fs')
const get_pdf_text = require('./get_pdf_text')
const lista_grupos = require('./json/lista_grupos.json')
const final_list = require('./json/final_list.json')

const crawler = async () => {
    const finalObj = []
    let grupo
    for(let i = 0; i < lista_grupos.length; i++){
        grupo = lista_grupos[i]

        const pivotObj = {
            grupo: grupo.grupo,
            curso: grupo.curso,
            resolucao: grupo.resolucao,
            links: grupo.links,
            text: ''
        }
        pivotObj.text = await downloadLinks(grupo.links)
        finalObj.push(pivotObj)
    }

    fs.writeFileSync('./json/final_list.json', JSON.stringify(finalObj))
}

const downloadLinks = async (links) => {
    let text = ''
    let link
    for(let i = 0; i < links.length; i++){
        link = links[i]
        text += ' ' + await get_pdf_text(link)
    }

    return text
}

const remove_special_char = async () => {
    const newFinal = []
    final_list.forEach((list) => {
        list.text = list.text.replace(/\n/g, ' ')
        list.text = list.text.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, ' ')
        list.text = list.text.replace(/[0-9]/gi, ' ')
        list.text = list.text.replace(/[^a-zA-ZáàâãéèêíïóôõöúçñÁÀÂÃÉÈÊÍÏÓÔÕÖÚÇÑ ]/gi, ' ')
        list.text = list.text.replace(/\s\s+/g, ' ').trim()
        newFinal.push(list)
    })
    fs.writeFileSync('./json/etlFinal.json', JSON.stringify(newFinal))
}

remove_special_char()