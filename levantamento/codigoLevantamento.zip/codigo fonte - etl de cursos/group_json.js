const fs = require('fs')
const get_pdf_text = require('./get_pdf_text')
const lista_cursos = require('./json/lista_cursos.json')

const group_json = () => {
    const finalObj = []
    const hash = {}
    let index = 0
    lista_cursos.forEach((curso) => {
        
        if(!hash[curso.grupo]){
            console.log(curso.grupo)
            hash[curso.grupo] = index
            finalObj.push({
                grupo: curso.grupo,
                curso: curso.curso,
                resolucao: curso.resolucao,
                links: []
            })
            index++
        }

        const grupo_index = hash[curso.grupo]

        finalObj[grupo_index].links.push(curso.link)
        
    })

    // fs.writeFileSync('lista_grupos.json', JSON.stringify(finalObj))
}

group_json()